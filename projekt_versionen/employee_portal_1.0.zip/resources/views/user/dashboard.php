<?php require(BASE_PATH . '/resources/views/layout/header.php'); ?>

     <!-- Hauptinhalt -->
     <div class="container-fluid p-4">
        <h1 class="mt-4">Dashboard</h1>
        <p>Willkommen im Mitarbeiterportal. Hier können Sie Ihre Daten einsehen und verwalten.</p>
    </div>

        
<?php require(BASE_PATH . '/resources/views/layout/footer.php'); ?>