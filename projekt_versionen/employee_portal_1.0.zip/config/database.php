<?php
return [
    'host' => 'localhost',
    'port' => '3306',
    'database' => 'emplyee_db',
    'username' => 'root',
    'password' => 'mysql',
    'charset' => 'utf8mb4',
];
?>