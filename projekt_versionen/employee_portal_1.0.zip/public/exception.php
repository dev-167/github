<?php
      include __DIR__ . '/../init.php';
      $controller = $container->make('controller');
      $controller->exception();
?>