   <?php
   // session variable $_SESSION kann nach der start_session verwendet werrden
      session_start();
      
      require __DIR__ . '/../init.php';
      $pathInfo = $_SERVER['PATH_INFO'];
      //Routes Array
      // PATH_INFO wird nur gesetzt, wenn die URL eine Struktur wie folgt hat http://localhost/Apps/employee-portal/public/index.php/index
      $routes = 
      [  
         '/index' => [
            'controller' => 'controller',
            'method' => 'index'
         ],
         '/user-details' => [
            'controller' => 'controller',
            'method' => 'userDetails'
         ],
         '/login' => [
            'controller' => 'loginController',
            'method' => 'login'
         ],
         '/dashboard' => [
            'controller' => 'loginController',
            'method' => 'dashboard'
         ],
         '/home' => [
            'controller' => 'controller',
            'method' => 'home'
         ],
         '/settings' => [
            'controller' => 'dashboardController',
            'method' => 'saveUserSettings'
         ],
         '/profil' => [
            'controller' => 'dashboardController',
            'method' => 'userProfil'
         ],
         '/logout' => [
            'controller' => 'loginController',
            'method' => 'logout'
         ],
      ];

      if(isset($routes[$pathInfo]))
      {
         $route = $routes[$pathInfo];
         $controller = $container->make($route['controller']);
         $method = $route['method'];
         $controller->$method();
      }

      // Damit werden POST-Anfragen an /logout verarbeitet.
      if ($_SERVER['REQUEST_METHOD'] === 'POST' && $pathInfo === '/logout') {
         $controller = $container->make('loginController');
         $controller->logout();
         exit;
     }
     
      
      // if($pathInfo == "/index")
      // {
      //    $controller = $container->make('controller');d
      //    $controller->index();
      // }
      // elseif($pathInfo == "/user-details")
      // {
      //    $controller = $container->make('controller');
      //    $controller->userDetails();
      // }
      ////////////////findAll////////////////


      ////////////////findById////////////////
      // echo "<br>";
      // $id = $userRepository->findById(1);
      // echo '<br>';
      // echo $id->email;
      // echo '<br>';

      ////////////////findByEmail////////////////
      // $email = $userRepository->findByEmail("anna.beispiel@example.com");
      // echo $email['name'];

      //new UserModel Object for save Object
      // $user_1 = new App\Model\UserModel(
      //    null,  // id (wird automatisch gesetzt, wenn das User-Objekt gespeichert wird)
      //    "Franz Beispiel",
      //    "franz.beispiel@example.com",
      //    null,
      //    1,     // role_id
      //    "Team Lead",
      //    "Team C",
      //    "09876523232",
      //    "avatar.jpg"
      //); // Passwort wird automatisch generiert und gehasht
      // echo "<br>";

      ////////////////save////////////////
      // if($userRepository->save($user_1))
      // {
      //    echo "Benutzer wurde erfolgreich aktuallisiert";
      // }
      // else
      // {
      //    echo "Fehler beim aktuallisieren des Benutzers";
      // }

      ////////////////delete////////////////

      // if($delete_user = $userRepository->delete(2))
      // {
      //    echo "Benutzer erfolgreich gelöscht!";
      // }
      //    else{
      //    echo "Fehler beim löschen des Benutzers";
      // }

      //New initialisation - findById = id2
