<?php
namespace App\Core;
abstract class AbstractController
{
        // Render-Funktion zum Laden einer View und Übergeben von Daten
        protected function render($view,$params)
        {
            // Daten als Variablen verfügbar machen
            extract($params);
            // Den Pfad zur View-Datei definieren
            $viewPath = __DIR__ . "/../../resources/views/{$view}.php";
            // Überprüfen, ob die View existiert
            if (file_exists($viewPath)) {
                include $viewPath;
            } else {
                var_dump($viewPath);
                var_dump("<br>");
                var_dump("<br>");
                var_dump("<br>");
                var_dump($view);
                die("View {$view} not found!");
            }
        }
}

?>