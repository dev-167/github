<?php

namespace App\Admin;

use App\Core\AbstractController;
use App\User\LoginController;
use App\User\LoginService;

class DashboardController extends AbstractController
{
    // Konstruktor für Dependency Injection
    public function __construct(DashboardService $dashboardService)
    {
        $this->dashboardService = $dashboardService;
    }

    public function dashboard()
    {
        $this->render("admin/dashboard");
    }

}


?>