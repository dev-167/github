<?php
namespace App\User;

use App\Core\AbstractController;

class LoginController extends AbstractController
{

     // Konstruktor für Dependency Injection
    public function __construct(LoginService $loginService)
    {
        $this->loginService = $loginService;
    }

    public function dashboard()
    {
        // Login Check
        $this->loginService->check();
        // keine Parameter daher das leere array
        // Wenn eingeloggt, dann gehts zum Dashboard

        //Administrator Abfrage
        if($_SESSION["team"] === "Administrator")
        {
            $this->render("admin/dashboard", []);
        }
        else
        {
            $this->render("user/dashboard", []);
        }
    }

    public function logout()
    {
        $this->loginService->logout();
        header("Location: login"); // zur login seite verweisen
        exit(); // Wichtig, um sicherzustellen, dass kein weiterer Code ausgeführt wird
    }

    public function login()
    {
        // var_dump(password_hash("findus92$",PASSWORD_DEFAULT));
        //var_dump(password_hash("Franz Beispiel12",PASSWORD_DEFAULT));
        // var_dump(password_hash("admin123$",PASSWORD_DEFAULT));

        // Errror am anfang auf nichts
        $error = null; // error inizialsiert
        if(!empty($_POST['email']) || !empty($_POST['password']))
        {
            $email = $_POST['email'];
            $password = $_POST['password'];

            // Einloggen durchführen, attempt fragt ob username und password richtig sind und fragt bei der Datenbank nach
            if($this->loginService->attempt($email,$password))
            {
                if($_SESSION['team'] === "Administration")
                {
                    header("Location: admin/dashboard");
                }
                else
                {
                    header("Location: dashboard"); // Weiterleitung. Letzter schrägstrich wird ausgetauscht
                }
                return;
            }
            else
            {
                $error = true;
            }   
        }
        // Einloggen durchführen
        $this->render("user/login",[
            'error' => $error
        ]);
    }

    public function adminLogin()
    {
        
    }
}
?>