<?php

namespace App\User;

use App\Core\AbstractModel;


class UserModel extends AbstractModel
{
    // Attribute deklariert
    public $id;
    public $name;
    public $surname;
    public $email;
    public $password;  // optionales Passwort
    public $role_ID;
    public $position;
    public $team;
    public $phone;
    public $avatar;

    // public function __construct(
    //     ?int $id = null,
    //     string $name = '',
    //     string $email = '',
    //     ?string $password = null,
    //     ?int $role_id = null, // Nullable Integer
    //     string $position = '',
    //     string $team = '',
    //     string $phone = '',
    //     string $avatar = ''
    // )
    // {
    //     // Werte werden zugewiesen
    //     $this->id = $id;
    //     $this->name = $name;
    //     $this->email = $email;
    //     // Passwort generieren, falls keines vorhanden ist
    //     $this->password = $password !== '' ? password_hash($password, PASSWORD_DEFAULT) : password_hash($this->generatePassword(), PASSWORD_DEFAULT);
    //     $this->role_id = $role_id; // Keine Typverletzung mehr bei NULL
    //     $this->position = $position;
    //     $this->team = $team;
    //     $this->phone = $phone;
    //     $this->avatar = $avatar;
    // }
    // Methode zur Konventierung in ein Array
    // public function toArray(): array
    // {
    //     return[
    //         'id' => $this->id,
    //         'name' => $this->name,
    //         'email' => $this->email,
    //         'password' => $this->password,  // Das Passwort ist jetzt auch hier
    //         'role_id' => $this->role_id,
    //         'position' => $this->position,
    //         'team' => $this->team,
    //         'phone' => $this->phone,    
    //         'avatar' => $this->avatar,
    //     ];
    // }
    // Hilfsfunktion, um ein zufälliges Passwort zu erstellen
    // private function generatePassword(): string
    // {
    //     return bin2hex(random_bytes(6)); // 12-stelliges Passwort
    // }
}