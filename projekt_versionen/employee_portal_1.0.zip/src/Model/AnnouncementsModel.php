<?php

namespace App\Model;

use App\Core\AbstractModel;


class AnnouncementsModel extends AbstractModel
{
    // Attribute deklariert
    public $id;
    public $title;
    public $content;
    public $posted_by;
    
}