employee-portal

1. Ordnerstruktur erstellt. Check.

Ordnerstruktur:

employee-portal/
├── app/                 # PHP-Logik (Controller, Models)
├── public/              # Öffentlich zugängliche Dateien (index.php, CSS, JS)
├── resources/           # Views (HTML, Blade-Templates bei Laravel)
├── database/            # Datenbank-Migrations- und Seeder-Dateien
├── tests/               # Tests (Unit-Tests und Feature-Tests)
├── config/              # Konfigurationsdateien
└── README.md            # Beschreibung des Projekts

Verzeichnisstruktur:

/projekt_root
    ├── /public            <-- Öffentliche Dateien (z. B. index.php, Assets)
    ├── /src               <-- Haupt-Quellcode
    │   ├── /Core          <-- Kernfunktionalitäten (z. B. AbstractRepository, PDO-Verbindung)
    │   ├── /Model         <-- Deine Klassen (z. B. User, Product)
    │   ├── /Repository    <-- Repository-Klassen (z. B. UserRepository)
    │   ├── /Controller    <-- Controller für die Business-Logik (z. B. UserController)
    │   ├── /View          <-- Views/HTML-Templates (z. B. Benutzeransicht)
    ├── /config            <-- Konfigurationsdateien (z. B. Datenbankverbindung)
    ├── /tests             <-- Unit-Tests und andere Tests
    ├── /vendor            <-- Abhängigkeiten (z. B. Composer Libraries)
    ├── composer.json      <-- Composer Konfigurationsdatei
    └── init.php           <-- Initialisierung des Projekts



#####################################################################################

2. Datenbank erstellen. 

Datenbankmodell: (Rawversion 1.0)

employee_db (1.0)

    Tabelle users (für Mitarbeiterdaten).
    Tabelle roles (für Rechte und Rollen).
    Tabelle tasks (für Aufgaben).




#####################################################################################



TodO 

1. Struktur bildlich daarstellen
2. ganz wichtig, bei dem Admin Login in den benötigten Controllern wird der loginService benötigt. Siehe PHP Bootcamp Schulung Video 147. Ab Minute 12.
3. Verbesserung: 
Um weniger Code im Bereich HTML zu benutzen zb bei einer Form mit einer Methode zb  :  
<?php form_text("title", "Title: $entry->title); >
4. Login verfahren optimalisieren, so dass erstmal das password automatisch in der db gescriptet wird 
////////////////////////////////Admin Login////////////////////////////////
5. Login für Admin einrichten
    a.)LoginService.php->attempt function->password_verify abfrage ("Sobald die Abfrage des Passwort gültig ist bekommt der Login eine weitere $_SESSION namens "team"")
    b.)LoginController.php->login()->nach der attempt($user,$password) Abfrage wird eine weitere Abfrage gestellt, ob es sich um das team "Administration" handelt. Dann wird via header auf das admin/dashboard verwiesen.

6. adminController einrichten um das admin/dashboard aufzurufen.


Falls du ein MVC-Framework oder eine eigene Controller-Logik verwendest, muss ein AdminController existieren, der die admin/dashboard-Route verarbeitet:

class AdminController
{
    public function dashboard()
    {
        $this->render("admin/dashboard"); // Stellt sicher, dass die View aus dem richtigen Ordner geladen wird
    }
}

Falls dein System nur eine zentrale index.php als Router verwendet, dann überprüfe, ob admin/dashboard darauf korrekt verweist.


////////////////////////////////Admin Login////////////////////////////////
Row Avatar bearbeiten. 
Avatar soll als Image genutzt werden um ein Mitarbeiter Foto hochladen zu können


5. 
    adminLogin function erstellen.
    abfrage, dass anhand der Fachabteilung




Folgende Pages für den User sind aktiv unter  :  
Resources/views/user

Login ins User Dashboard des Mitarbeiters
    login.php -> dashboard.php
Dashboard
    dashboard.php
Dashboard Subpages
    -> home.php
    -> profil.php
    -> settings.php
    -> user-details.php
Admin
    -> login.php
    -> dashboard.php


