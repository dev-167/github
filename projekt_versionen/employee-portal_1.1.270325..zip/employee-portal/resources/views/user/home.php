<?php require(BASE_PATH . '/resources/views/layout/header.php'); ?>



<?php require(BASE_PATH . '/resources/views/layout/footer.php'); ?>