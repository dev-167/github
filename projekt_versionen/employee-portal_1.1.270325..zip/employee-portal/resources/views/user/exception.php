<?php

var_dump("davor");

var_dump("danach");