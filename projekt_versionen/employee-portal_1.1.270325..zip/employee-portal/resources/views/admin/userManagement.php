<?php require(BASE_PATH . '/resources/views/layout/header.php'); ?>

     <!-- Hauptinhalt -->
     <div class="container-fluid p-4">
        <h1 class="mt-4">User Management</h1>
        
    </div>

        
<?php require(BASE_PATH . '/resources/views/layout/footer.php'); ?>