<?php
//Falls du viele Dateien einbindest, könnte es sinnvoll sein, 
//ein globales Root-Verzeichnis für dein Projekt zu definieren. 
define('BASE_PATH', __DIR__ . '/..');
?>