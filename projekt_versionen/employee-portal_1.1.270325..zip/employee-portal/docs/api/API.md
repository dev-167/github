# API-Dokumentation

## Endpoints
### GET /api/users
Gibt eine Liste aller Benutzer zurück.

### POST /api/users
Erstellt einen neuen Benutzer.

### Beispiel
```json
{
    "name": "Max Mustermann",
    "email": "max@example.com"
}