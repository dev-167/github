   <?php
   // Startet die PHP-Session. Info: if Abfrage stellt sicher, dass keine Session doppelt gestartet wird
    if (session_status() === PHP_SESSION_NONE) {
      session_start();
    }
    // Standard-Rolle setzen, falls nicht vorhanden
    if (!isset($_SESSION['team'])) {
        $_SESSION['team'] = 'user';
    }
    // Globale Variable für Benutzerrolle setzen
    $userRole = $_SESSION['team'];
   // Lädt alle wichtigen Konfigurationsdateien
      require __DIR__ . '/../init.php';
   // Läudt die Routen  
     $routes = require __DIR__ . '/../config/routes.php';
   // Erstellt das Router Objekt
     $router = new \App\Core\Router($routes, $container);
   // Enthält die aktuelle URL Route
     $pathInfo = $_SERVER['PATH_INFO'] ?? '/';
   // Führt die richtige Route aus
     $router->dispatch($pathInfo);

?>