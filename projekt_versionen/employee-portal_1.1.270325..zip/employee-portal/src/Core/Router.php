<?php

namespace App\Core;

class Router
{
    // Speichert alle definierten Routen
    private array $routes;
    // Verwaltet die Controller-Instanz 
    private Container $container;
    // Konstruktor speichert die übergebenen Routen und den Container
    public function __construct(array $routes, Container $container)
    {
        $this->routes = $routes;
        $this->container = $container;
    }

    // Methode dispatch sucht die passende Route und führt sie aus
    public function dispatch(string $path)
    {
        // Prüft, ob die aktuelle URL in den definierten Routen existiert
        if (isset($this->routes[$path])) {
            // Holt den passenden Eintrag aus dem Array
            $route = $this->routes[$path];
            // Die Methode, die aufgerufen werden soll, z. B. "dashboard"
            $methodName = $route['method'];
            // Controller Name
            $controller = $this->container->make($route['controller']);

            if(method_exists($controller,$methodName))
            {
                // Führt die Controller Methode auf
                $controller->$methodName();
            }
            else
            {
                // Fehlerbehandlung
                $this->handleNotFound();
            }
        }
        else
        {
            $this->handleNotFound();
        }
    }
    // Gibt Fehlerseite zurück
    private function handleNotFound() 
    {
        http_response_code(404);
        echo "404 - Seite nicht gefunden";
    }
// {
//     http_response_code(404); // Setzt den HTTP-Status-Code auf 404
//     echo "404 - Seite nicht gefunden"; // Gibt eine einfache Fehlerseite aus
// }

}

// session_start();
      
// require __DIR__ . '/../init.php';
// $pathInfo = $_SERVER['PATH_INFO'];
// //Routes Array
// // PATH_INFO wird nur gesetzt, wenn die URL eine Struktur wie folgt hat http://localhost/Apps/employee-portal/public/index.php/index


// if(isset($routes[$pathInfo]))
// {
//    $route = $routes[$pathInfo];
//    $controller = $container->make($route['controller']);
//    $method = $route['method'];
//    $controller->$method();
// }
// else
// {
//    http_response_code(404);
//    echo "<center><h1>404 - Seite nicht gefunden</h1></center>";
// }

// // Damit werden POST-Anfragen an /logout verarbeitet.
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && $pathInfo === '/logout') {
//    $controller = $container->make('loginController');
//    $controller->logout();
//    exit;
// }
