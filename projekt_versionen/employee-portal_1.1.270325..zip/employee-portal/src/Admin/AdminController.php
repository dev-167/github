<?php

namespace App\Admin;

use App\Core\AbstractController;
use App\User\DashboardController;
use App\User\DashboardService;
use App\User\LoginController;
use App\User\LoginService;
use App\Admin\AdminService;

class AdminController extends AbstractController
{
    // Überprüft Login Anfrage anhand der Sessions auf User mit der team Kennzeichnung "Administrator". Anschließend wird zur /admin/dashboard.php Page verwiesen
    public function dashboard()
    {
        if (!isset($_SESSION['login']) || $_SESSION['team'] !== 'Administration') {
            header("Location: /login");
            exit;
        }

        // Admin Dashboard anzeigen
        echo $this->render('admin/dashboardAdmin',[
            'title' => 'Admin Dashboard',
        ]);
    }

    public function userProfil()
    {
        $user = $this->dashboardService->showUser();

        // Die Render-Funktion aufrufen
        $this->render("user/profil", [
            'user' => $user
        ]);
    }

}


?>